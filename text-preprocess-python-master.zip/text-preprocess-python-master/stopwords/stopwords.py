stop_words_list = ["hey", "hi", "a", "the"]
